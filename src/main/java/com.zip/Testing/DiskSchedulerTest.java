/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Testing;
import Schedulers.*;
import  LogicalStrucures.Process;
import Managers.FileSystemManager;
import Managers.ProcessManager;


/**
 *
 * @author santi
 */
/**
 * Pruebas para los algoritmos de planificación de disco
 */
/**
 * Clase de pruebas modular para algoritmos de planificación de disco.
 * Diseñada para ser extendida con nuevos planificadores fácilmente.
 */
